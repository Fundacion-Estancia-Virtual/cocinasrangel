<?php
define('HOST', 'http://localhost:5000/');
// base de datos
$db = new DB("213.190.6.106","u811232073_general_public","u811232073_asesor","6Xr0|PV!p");


 ?>
